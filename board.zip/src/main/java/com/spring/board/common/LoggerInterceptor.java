package com.spring.board.common;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
public class LoggerInterceptor extends HandlerInterceptorAdapter{
	protected final Logger logger = LoggerFactory.getLogger(LoggerInterceptor.class);
	// 역할 : 처음 BoardList의 게시글의 갯수를 받아오기 위해 사용된다.
	// preHandle : 실행하기전에 호출 되는 메소드
	@SuppressWarnings("rawtypes")
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.debug("===========================LoggerInterceptor START========================");
		logger.debug(" URI [{}]," +request.getRequestURI());
		
		Enumeration paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()) {
			String key = (String)paramNames.nextElement();
			String value = request.getParameter(key);
			logger.debug("RequestParameter Data ==> "+key+":"+value+"");
		}
		
		return super.preHandle(request, response, handler);
	}
	// postHandle : 컨트롤러를 실행하고 난 후에 호출, 컨틀로러가 돌려준 작업결과를 참조하거나 조작할 수 있다.
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		logger.debug("===========================LoggerInterceptor END========================");
		
	}
}
